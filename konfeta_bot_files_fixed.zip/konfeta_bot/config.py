import os
from dotenv import load_dotenv

load_dotenv()

BOT_TOKEN = os.getenv("BOT_TOKEN", "").strip()
DATABASE_PATH = os.getenv("DATABASE_PATH", "konfeta.db")

# Владелец бота «Конфета»
OWNER_ID = 8875523628

# Первый инспектор
FIRST_INSPECTOR_ID = 1863646015

SUPPORT_LINK = "https://t.me/candy_cm_chat"
